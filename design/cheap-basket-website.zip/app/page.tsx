 "use client";
import {useState} from "react";
import {ArrowRight,Check,MapPin,ScanLine,ShoppingBasket,Search,Star,ChevronDown} from "lucide-react";

const features=[
 ["01","Səbətini yarat","Almaq istədiyin məhsulları axtar və səbətinə əlavə et."],
 ["02","Qiymətləri müqayisə et","Cheap Basket marketlərdəki qiymətləri analiz edir."],
 ["03","Ən sərfəli marketi tap","Bütün səbət üçün ən sərfəli marketi və yaxın filialı gör."]
];

export default function Page(){
 const [lang,setLang]=useState(false);
 const [plus,setPlus]=useState(false);
 return <main>
  <header className="nav">
   <div className="container nav-inner">
    <div className="logo"><div className="logo-mark"><ShoppingBasket size={21}/></div><span>Cheap<br/><b>Basket</b></span></div>
    <nav><a href="#how">Necə işləyir?</a><a href="#features">Üstünlüklər</a><a href="#plus">Plus</a><a href="#faq">FAQ</a></nav>
    <div className="nav-actions"><button className="lang" onClick={()=>setLang(!lang)}>AZ <ChevronDown size={14}/></button><a className="download" href="#download">Tətbiqi yüklə</a></div>
   </div>
  </header>

  <section className="hero">
   <div className="container hero-grid">
    <div className="hero-copy">
     <span className="eyebrow">● Daha ağıllı alış-veriş</span>
     <h1>Alış-verişə getməzdən əvvəl <span>ən sərfəli marketi</span> tap.</h1>
     <p>Almaq istədiyin məhsulları səbətə əlavə et. Cheap Basket qiymətləri müqayisə etsin və sənə ən sərfəli marketi göstərsin.</p>
     <div className="store-buttons"><a href="#download"> App Store</a><a href="#download">▶ Google Play</a></div>
     <div className="trust"><div className="avatars"><i>Ə</i><i>A</i><i>N</i><i>M</i></div><span><b>10.000+ istifadəçi</b><br/>Artıq daha ağıllı alış-veriş et!</span></div>
    </div>
    <div className="hero-visual">
      <div className="red-orb"></div>
      <div className="phone phone-back"><div className="phone-screen"><div className="mini-top">Cheap Basket <span>⌁</span></div><div className="mini-title">Səbətim</div><div className="mini-list"><b>🥛 Süd 1L <em>₼2.05</em></b><b>🥚 Yumurta <em>₼2.85</em></b><b>🍗 Toyuq <em>₼7.90</em></b><b>🫗 Yağ <em>₼3.29</em></b></div></div></div>
      <div className="phone phone-front"><div className="phone-screen result"><div className="mini-top">Cheap Basket <span>♡</span></div><div className="map-mini"><span className="you-dot"></span><span className="market-pin">●</span><span className="road"></span></div><div className="result-card"><small>Ən sərfəli seçim</small><strong>Araz Market</strong><b>₼42.80</b><span>💚 2.80 ₼ qənaət</span><button>Xəritədə göstər</button></div></div></div>
    </div>
   </div>
  </section>

  <section className="how" id="how"><div className="container"><h2>Necə işləyir?</h2><p className="section-sub">3 sadə addımda daha ağıllı alış-veriş et.</p><div className="steps">{features.map(([n,t,d])=><div className="step" key={n}><span>{n}</span><div className="step-icon">{n==="01"?<ShoppingBasket/>:n==="02"?<Search/>:<MapPin/>}</div><h3>{t}</h3><p>{d}</p></div>)}</div></div></section>

  <section className="choice" id="features"><div className="container choice-grid"><div><h2>10 məhsul.<br/><span>3 market.</span><br/><b>1 ən sərfəli seçim.</b></h2><p>Cheap Basket səbətindəki bütün məhsulları müqayisə edir və sənə ən sərfəli alış-veriş nöqtəsini göstərir.</p><a className="red-btn" href="#download">Tətbiqi yüklə <ArrowRight size={17}/></a></div><div className="basket-scene"><div className="big-phone"><div className="phone-content"><small>10 məhsul · qiymət müqayisəsi</small><h3>Araz Market</h3><strong>₼42.80</strong><div className="price-line">Bravo <b>₼45.60</b></div><div className="price-line">Bazarstore <b>₼44.30</b></div><div className="price-line">Neptun <b>₼43.90</b></div></div></div><div className="grocery">🥬 🥕 🥛 🥖</div></div></div></section>

  <section className="benefits"><div className="container benefit-row"><div><ScanLine/><b>Real qiymətlər</b><small>Günlük yenilənir</small></div><div><MapPin/><b>Yaxın filiallar</b><small>Xəritədə göstərilir</small></div><div><Check/><b>Etibarlı məlumat</b><small>AI ilə analiz olunur</small></div><div><ShoppingBasket/><b>Vaxtına qənaət</b><small>Daha rahat alış-veriş</small></div></div></section>

  <section className="pricing" id="plus"><div className="container"><h2>Sənin üçün uyğun seçim</h2><p className="section-sub">Sadə başla. İstəsən daha çox qənaət et.</p><div className="plans">
    <div className="plan"><h3>FREE</h3><div className="price">0 ₼ <small>/ həmişə</small></div>{["1 səbət yaratmaq","Qiymətləri müqayisə etmək","Ən sərfəli marketi tapmaq","Yaxın filialı göstərmək","Barkod skan etmək"].map(x=><p key={x}><Check/> {x}</p>)}<button>Pulsuz başla</button></div>
    <div className="plan featured"><span className="popular">ƏN POPULYAR</span><h3>PLUS</h3><div className="price">2.99 ₼ <small>/ ay</small></div>{["Limitsiz səbət","Qiymət tarixçəsi","Qiymət düşəndə bildiriş","AI tövsiyələri","Qənaət statistikası"].map(x=><p key={x}><Check/> {x}</p>)}<button onClick={()=>setPlus(!plus)}>Plus-a keç</button></div>
  </div></div></section>

  <section className="reviews"><div className="container"><h2>İstifadəçilərimiz nə deyir?</h2><div className="review-grid">{["Artıq marketə getməzdən əvvəl mütləq yoxlayıram. Hər dəfə qənaət edirəm!","Çox rahatdır. Xəritə ilə yaxın filialı göstərməsi superdir.","Qiymətləri müqayisə etmək çox vaxta qənaət edir."].map((x,i)=><div className="review" key={x}><div className="stars">{[1,2,3,4,5].map(n=><Star key={n} size={14} fill="currentColor"/>)}</div><p>“{x}”</p><b>{["Nigar R.","Tural M.","Aysel K."][i]}</b></div>)}</div></div></section>

  <section className="download-section" id="download"><div className="container download-box"><div><h2>Cheap Basket-i indi yüklə</h2><p>Daha ağıllı alış-verişə bu gün başla.</p></div><div className="store-buttons"><a href="#"> App Store</a><a href="#">▶ Google Play</a></div></div></section>

  <footer id="faq"><div className="container footer-grid"><div className="footer-brand"><div className="logo"><div className="logo-mark"><ShoppingBasket size={21}/></div><span>Cheap<br/><b>Basket</b></span></div><p>Daha ağıllı alış-veriş.<br/>Daha çox qənaət.</p></div><div><b>Məlumat</b><a href="#how">Necə işləyir</a><a href="#features">Üstünlüklər</a><a href="#plus">FAQ</a></div><div><b>Şirkət</b><a href="#">Haqqımızda</a><a href="#">Əlaqə</a><a href="#">Məxfilik siyasəti</a></div><div><b>Sosial media</b><div className="social">Instagram · TikTok · LinkedIn</div></div></div><div className="container copyright">© 2026 Cheap Basket. Bütün hüquqlar qorunur.</div></footer>
 </main>
}