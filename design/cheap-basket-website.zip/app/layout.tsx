import "./globals.css";
export const metadata={title:"Cheap Basket — Alış-verişə getməzdən əvvəl müqayisə et",description:"Səbətini yarat, ən sərfəli marketi tap."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="az"><body>{children}</body></html>}