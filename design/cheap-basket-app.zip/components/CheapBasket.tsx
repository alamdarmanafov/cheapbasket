 "use client";

import { useMemo, useState } from "react";
import {
  Bell, Camera, ChevronRight, CircleUserRound, Home, MapPin,
  Minus, Navigation, Plus, Search, ScanLine, ShoppingBasket,
  Trash2, User, WalletCards, X, Sparkles, CheckCircle2, Store
} from "lucide-react";

type Product = {
  id: number;
  name: string;
  brand: string;
  size: string;
  price: number;
  market: string;
  image: string;
};

const products: Product[] = [
  { id: 1, name: "Sütaş Süd", brand: "Sütaş", size: "1L", price: 2.05, market: "Araz", image: "🥛" },
  { id: 2, name: "Toyuq filesi", brand: "Araz", size: "1kg", price: 7.90, market: "Araz", image: "🍗" },
  { id: 3, name: "Yumurta", brand: "OBA", size: "10 ədəd", price: 2.85, market: "Neptun", image: "🥚" },
  { id: 4, name: "Günəbaxan yağı", brand: "Azərsun", size: "1L", price: 3.29, market: "Bravo", image: "🫗" },
  { id: 5, name: "Düyü", brand: "Milla", size: "1kg", price: 3.20, market: "Araz", image: "🍚" },
  { id: 6, name: "Qəhvə", brand: "Nescafé", size: "200g", price: 8.50, market: "Bravo", image: "☕" },
];

const marketTotals = [
  { name: "Araz Market", total: 42.80, distance: "1.2 km", time: "5 dəqiqə", color: "green" },
  { name: "Bravo", total: 45.60, distance: "2.1 km", time: "7 dəqiqə", color: "orange" },
  { name: "Bazarstore", total: 44.30, distance: "3.4 km", time: "10 dəqiqə", color: "yellow" },
];

export default function CheapBasket() {
  const [tab, setTab] = useState<"home"|"basket"|"markets"|"scan"|"profile">("home");
  const [basket, setBasket] = useState<Product[]>(products.slice(0, 4));
  const [search, setSearch] = useState("");
  const [showResult, setShowResult] = useState(false);
  const [showScanner, setShowScanner] = useState(false);

  const filtered = useMemo(
    () => products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.brand.toLowerCase().includes(search.toLowerCase())),
    [search]
  );

  const basketTotal = basket.reduce((sum, p) => sum + p.price, 0);
  const best = marketTotals[0];

  function addProduct(p: Product) {
    if (!basket.some(x => x.id === p.id)) setBasket([...basket, p]);
  }

  function removeProduct(id: number) {
    setBasket(basket.filter(p => p.id !== id));
  }

  return (
    <main className="app-shell">
      <div className="phone">
        <header className="topbar">
          <div className="brand">
            <div className="brand-icon"><ShoppingBasket size={20}/></div>
            <span>Cheap<br/><b>Basket</b></span>
          </div>
          <div className="location"><MapPin size={14}/> Bakı, Azərbaycan</div>
          <button className="icon-btn"><Bell size={19}/></button>
        </header>

        {tab === "home" && (
          <section className="screen">
            <h1>Bu gün<br/><span>nə alırsan?</span></h1>
            <p className="sub">Alış-verişə getməzdən əvvəl ən sərfəli səbətini hazırla.</p>

            <div className="searchbox">
              <Search size={18}/>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Məhsul axtar..." />
              <button onClick={()=>setShowScanner(true)}><ScanLine size={18}/></button>
            </div>

            <button className="scan-card" onClick={()=>setShowScanner(true)}>
              <div className="scan-symbol"><ScanLine/></div>
              <div>
                <strong>Barkodu skan et</strong>
                <small>Məhsulu tanı, ən ucuzunu tap</small>
              </div>
              <ChevronRight/>
            </button>

            <div className="quick-grid">
              <button onClick={()=>setShowScanner(true)}><Camera/><b>Məhsulun şəklini çək</b></button>
              <button onClick={()=>setTab("basket")}><WalletCards/><b>Siyahını əlavə et</b></button>
            </div>

            <div className="basket-summary" onClick={()=>setTab("basket")}>
              <div>
                <small>Sənin səbətin</small>
                <h2>{basket.length} məhsul</h2>
                <strong>₼{basketTotal.toFixed(2)}</strong>
              </div>
              <div className="basket-art">🛒</div>
            </div>

            {search && (
              <div className="results">
                <h3>Məhsullar</h3>
                {filtered.map(p=>(
                  <div className="product-row" key={p.id}>
                    <span className="emoji">{p.image}</span>
                    <div className="grow"><b>{p.name}</b><small>{p.brand} · {p.size}</small></div>
                    <strong>₼{p.price.toFixed(2)}</strong>
                    <button className="plus" onClick={()=>addProduct(p)}><Plus size={16}/></button>
                  </div>
                ))}
              </div>
            )}

            <h3 className="section-title">Populyar kateqoriyalar</h3>
            <div className="categories">
              {["🥛 Süd","🥩 Ət","🥬 Tərəvəz","🍊 Meyvə","🥤 İçkilər"].map(x=><div key={x}>{x}</div>)}
            </div>

            <div className="ai-banner">
              <Sparkles/>
              <div><b>Ağıllı alış-veriş</b><small>Daha çox qənaət et!</small></div>
              <button onClick={()=>setShowResult(true)}>→</button>
            </div>
          </section>
        )}

        {tab === "basket" && (
          <section className="screen">
            <div className="screen-title"><h2>Səbətim</h2><button onClick={()=>setBasket([])}><Trash2/></button></div>
            <p className="muted">{basket.length} məhsul · ₼{basketTotal.toFixed(2)}</p>

            <div className="product-list">
              {basket.map(p=>(
                <div className="basket-item" key={p.id}>
                  <span className="emoji large">{p.image}</span>
                  <div className="grow"><b>{p.name} {p.size}</b><small>{p.brand}</small><strong>₼{p.price.toFixed(2)}</strong></div>
                  <button onClick={()=>removeProduct(p.id)}><Minus/></button>
                  <span>1</span><button onClick={()=>addProduct(p)}><Plus/></button>
                </div>
              ))}
            </div>

            <button className="add-product" onClick={()=>setTab("home")}><Plus/> Məhsul əlavə et</button>
            <button className="primary" onClick={()=>setShowResult(true)}><Sparkles/> Qiymətləri müqayisə et</button>
          </section>
        )}

        {tab === "markets" && (
          <section className="screen">
            <h2>Ən sərfəli market</h2>
            <div className="hero-result">
              <span className="pill green-pill">✓ Ən sərfəli seçim</span>
              <h3>Araz Market</h3>
              <div className="big-price">₼42.80</div>
              <p className="saving">🟢 Bravo-dan 2.80 ₼ daha ucuzdur!</p>
              <div className="mini-markets">
                {marketTotals.map(m=><div key={m.name}><b>{m.name.replace(" Market","")}</b><strong>₼{m.total.toFixed(2)}</strong><small>{m.name==="Araz Market"?"Ən sərfəli":`+₼${(m.total-best.total).toFixed(2)}`}</small></div>)}
              </div>
            </div>

            <div className="map-card">
              <div className="fake-map">
                <span className="you">●</span>
                <span className="route">╱╲╱╲</span>
                <span className="pin">●</span>
              </div>
              <div className="map-info">
                <b>Araz Market</b>
                <small>28 May filialı · 1.2 km · 5 dəqiqə</small>
              </div>
            </div>
            <button className="primary"><Navigation/> Xəritədə göstər</button>
          </section>
        )}

        {tab === "scan" && (
          <section className="scanner-screen">
            <div className="scanner-head"><button onClick={()=>setTab("home")}><X/></button><b>Barkodu skan et</b><span>⚡</span></div>
            <div className="camera-view">
              <div className="scan-frame"><div className="scan-line"/></div>
              <p>Barkodu çərçivəyə gətir</p>
            </div>
            <button className="shutter" onClick={()=>setShowResult(true)}>Scan</button>
            <div className="scan-bottom">Məhsul tanındıqdan sonra qiymətləri avtomatik müqayisə edəcəyik.</div>
          </section>
        )}

        {tab === "profile" && (
          <section className="screen">
            <div className="screen-title"><h2>Profil</h2><button><User/></button></div>
            <div className="profile-card"><CircleUserRound size={52}/><div><b>Ələmdar</b><small>İstifadəçi hesabı</small></div><ChevronRight/></div>
            {["Mənim məlumatlarım","Ünvanlarım","Sevimli marketlər","Bildirişlər","Dil","Valyuta","Dəstək","Tətbiqi qiymətləndir"].map(x=><div className="settings-row" key={x}><span>{x}</span><ChevronRight size={18}/></div>)}
          </section>
        )}

        <nav className="bottom-nav">
          {[
            ["home","Ana səhifə",Home],
            ["basket","Səbət",ShoppingBasket],
            ["markets","Marketlər",Store],
            ["scan","Skan et",ScanLine],
            ["profile","Profil",User],
          ].map(([key,label,Icon]: any)=>(
            <button key={key} className={tab===key?"active":""} onClick={()=>setTab(key)}>
              <Icon size={20}/><small>{label}</small>
              {key==="basket" && basket.length>0 && <i>{basket.length}</i>}
            </button>
          ))}
        </nav>

        {showResult && (
          <div className="modal-backdrop" onClick={()=>setShowResult(false)}>
            <div className="modal" onClick={e=>e.stopPropagation()}>
              <div className="modal-icon"><CheckCircle2/></div>
              <span className="pill green-pill">AI nəticəsi</span>
              <h2>Sənin üçün ən sərfəli seçim</h2>
              <h1>Araz Market</h1>
              <div className="big-price">₼42.80</div>
              <p>10 məhsullu səbətin üçün Araz Market daha sərfəlidir.</p>
              <p className="saving">💚 Təxminən 2.80 ₼ qənaət</p>
              <button className="primary" onClick={()=>{setShowResult(false);setTab("markets")}}>Xəritədə göstər</button>
            </div>
          </div>
        )}

        {showScanner && (
          <div className="modal-backdrop" onClick={()=>setShowScanner(false)}>
            <div className="scanner-modal" onClick={e=>e.stopPropagation()}>
              <div className="modal-top"><b>Barkod skanı</b><button onClick={()=>setShowScanner(false)}><X/></button></div>
              <div className="mini-camera"><ScanLine size={58}/></div>
              <p>Barkodu çərçivəyə gətir. Məhsul avtomatik tanınacaq.</p>
              <button className="primary" onClick={()=>{setShowScanner(false);setShowResult(true)}}>Skan et</button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}