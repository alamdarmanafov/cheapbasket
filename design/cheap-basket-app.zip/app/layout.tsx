import "./globals.css";

export const metadata = {
  title: "Cheap Basket",
  description: "Alış-verişdən əvvəl ən sərfəli marketi tap.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="az">
      <body>{children}</body>
    </html>
  );
}