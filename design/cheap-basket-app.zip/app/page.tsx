import CheapBasket from "../components/CheapBasket";

export default function Page() {
  return <CheapBasket />;
}